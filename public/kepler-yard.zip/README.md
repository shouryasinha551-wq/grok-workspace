# Kepler Yard

A self-contained orbital gravity sandbox. No build step and no server.

## Host on GitHub Pages

1. Create a new empty repository on GitHub.
2. Upload `index.html` to the repository root (this README can go too).
3. Open Settings → Pages.
4. Deploy from the `main` branch, folder `/ (root)`.
5. After a minute, the site is live at the Pages URL.

You can also open `index.html` directly in a browser.

Drag the sky to spawn a body, drag a planet to fling it, and use the time scale when you want the dance to hurry.
